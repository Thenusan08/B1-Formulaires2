<?php

$civilites = array("M." => "Monsieur", "Mme" => "Madame", "Mlle" => "Mademoiselle");
$raison_contact = array("renseignement" => "Renseignement", "reclamation" => "Réclamation", "commande" => "Commande");
$mode_reponse = array("email" => "Par email", "sms" => "Par SMS", "telephone" => "Par téléphone");


$nom = $prenom = $telephone = $email = $raison = $modes_reponse = $date_rappel = $message = "";
$errors = array();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["nom"])) {
        $errors[] = "Le champ nom est obligatoire.";
    } else {
        $nom = test_input($_POST["nom"]);
    }

    if (empty($_POST["prenom"])) {
        $errors[] = "Le champ prénom est obligatoire.";
    } else {
        $prenom = test_input($_POST["prenom"]);
    }

    if (empty($_POST["telephone"])) {
        $errors[] = "Le champ téléphone est obligatoire.";
    } else {
        $telephone = test_input($_POST["telephone"]);
    }


